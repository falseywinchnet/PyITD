template <class T> class Circular_Buffer {
private:
	std::unique_ptr<T[]> buffer;
	size_t head = 0;
	size_t tail = 0;
	size_t max_size;

public:
	Circular_Buffer<T>(size_t max_size)
		: buffer(std::make_unique<T[]>(max_size)), max_size(max_size) {};

	bool enqueue(T item) {
		if (!is_full()) {
			buffer[tail] = item;
			tail = (tail + 1) % max_size;
			return true;
		}
		return false;
	}
	 bool dequeue(T& item) {
    if (is_empty()) 
      return false; 

    item = buffer[head];
    head = (head + 1) % max_size;
    return true;
  }

	void discard() {
		if (!is_empty()) {
			head = (head + 1) % max_size;
		}
			//silently do absolutely jack-all if the buffer is empty
	}


	bool is_empty() { return head == tail; }

	bool is_full() { return (tail + 1) % max_size == head; }

	size_t size() {
		return (max_size + tail - head) % max_size;
	}
};

//this assumes you pre-allocate a buffer with Circular_Buffer<float> name(size);
//and that you will never exceed this size(every cycle you take away as much as you put in).
//otherwise, it will crash. But for what its designed to do, it does it well and fast.
//add stuff to the head with enqueue, take it off the other end with dequeue.
//use discard if you want to discard some of the samples off the dequeue end without using them(shave the buffer contents).


void mean_smooth_2d(std::array<std::array<double, 257>, 192>& input,std::array<std::array<double, 257>, 192>& output) {
    //remmeber to declare std::array<std::array<double, 257>, 192> temp;

    // Initialize temp array with zero
    temp.fill({0.0});

    // Mean smoothing over rows
    for (int i = 1; i < 191; i++) {
        for (int j = 1; j < 256; j++) {
            output[i][j] = (input[i][j-1] + input[i][j] + input[i][j+1]) / 3;
        }
    }

    // Mean smoothing over columns
    for (int i = 1; i < 191; i++) {
        for (int j = 1; j < 256; j++) {
            temp[i][j] = (input[i-1][j] + input[i][j] + input[i+1][j]) / 3;
        }
    }

    // Add temporary into output and divide by 2
    for (int i = 0; i < 192; i++) {
        for (int j = 0; j < 257; j++) {
            output[i][j] = (output[i][j] + temp[i][j]) / 2;
        }
    }

    // Edge values
    for (int i = 1; i < 191; i++) {
        output[i][0] = (input[i][1] + input[i][2] + input[i][0]) / 3;
        output[i][256] = (input[i][254] + input[i][255] + input[i][256]) / 3;
    }
    for (int j = 1; j < 256; j++) {
        output[0][j] = (input[1][j] + input[2][j] + input[0][j]) / 3;
        output[191][j] = (input[189][j] + input[190][j] + input[191][j]) / 3;
    }

    // Corner values
    output[0][0] = ((output[0][1] + output[1][0] + input[0][1] + input[1][0]) / 4 + input[0][0]) / 2;
    output[0][256] = ((output[0][255] + output[1][256] + input[0][255] + input[1][256]) / 4 + input[0][256]) / 2;
    output[191][0] = ((output[190][0] + output[191][1] + input[190][0] + input[191][1]) / 4 + input[191][0]) / 2;
    output[191][256] = ((output[190][256] + output[191][255] + input[190][256] + input[191][255]) / 4 + input[191][256]) / 2;
}
//should be a good 2d averaging function.



#include <iostream>
#include <cmath>
#include <array>

    std::array<std::array<double, 257>, 192> upper;
    std::array<std::array<double, 257>, 192> lower;
    std::array<std::array<double, 257>, 192> first;
    std::array<std::array<double, 257>, 192> second;

const int ROWS = 192;
const int COLS = 257;

std::array<std::array<double, COLS>, ROWS> x;
std::array<std::array<double, COLS>, ROWS> bayesian_weight;
std::array<std::array<double, COLS>, ROWS> bayesian_model;
std::array<std::array<double, COLS>, ROWS> model_weight;
std::array<std::array<double, COLS>, ROWS> posterior_mean;
std::array<std::array<double, COLS>, ROWS> initial_evidence;
std::array<std::array<double, COLS>, ROWS> evidence;
std::array<std::array<double, COLS>, ROWS> prior_mean;
std::array<std::array<double, COLS>, ROWS> prior_variance;
std::array<std::array<double, COLS>, ROWS> posterior_variance;
std::array<std::array<double, COLS>, ROWS> data_variance;

std::array<std::array<double, COLS>, ROWS> numba_fabada(const std::array<std::array<double, COLS>, ROWS>& data, double sigma) {
    x = data;

    for (auto& row : x) {
        for (auto& value : row) {
            if (std::isnan(value))
                value = 0;
        }
    }
    bayesian_weight.fill({0.0});
    bayesian_model.fill({0.0});
    model_weight.fill({0.0});
    posterior_mean.fill({0.0});
    initial_evidence.fill({0.0});
    evidence.fill({0.0});
    prior_mean.fill({0.0});
    prior_variance.fill({0.0});
    data_variance.fill({0.0});
    data_variance.fill({0.0});
    upper.fill({0.0});
    lower.fill({0.0});
    first.fill({0.0});
    second.fill({0.0});

	
    int iterations = 1;
    int N = x.size() * x[0].size();
    int max_iterations = 1000;
    double chi2_data = 0.0;
    double chi2_data_previous = 0.0;
    double chi2_data_derivative_previous = 0.0;
    double tolerance = 1e-15;
    double chi2_data_min = 0.0;
    double evidence_derivative = 0.0;
    for (auto& row : data_variance) {
        for (auto& value : row) {
            value = std::pow(sigma, 2);
        }
    }

    for (size_t i = 0; i < x.size(); ++i) {
        for (size_t j = 0; j < x[i].size(); ++j) {
            if (std::isnan(data[i][j]))
                data_variance[i][j] = 1e-15;

            if (data_variance[i][j] == 0)
                data_variance[i][j] = 1e-15;

            posterior_variance[i][j] = data_variance[i][j];
            prior_variance[i][j] = data_variance[i][j];
            prior_mean[i][j] = x[i][j];
        }
    }
	
    for (size_t i = 0; i < x.size(); ++i) {
        for (size_t j = 0; j < x[i].size(); ++j) {
        upper[i][j] = std::pow(std::sqrt(data_variance[i][j]) * -1, 2);
        lower[i][j] = 2 * data_variance[i][j];
        first[i][j] = (-upper[i][j] / lower[i][j]);
        second[i][j] = std::sqrt(2 * M_PI) * data_variance[i][j];
        initial_evidence[i][j] = std::exp(first[i][j]) / second[i][j];
	evidence[i][j] = initial_evidence[i][j];

    }
}
    evidence_previous = std::mean(evidence);

    while (true) {
        // GENERATES PRIORS
        for (int i = 1; i < N - 1; ++i) {
            prior_mean[i / COLS][i % COLS] = (posterior_mean[(i - 1) / COLS][(i - 1) % COLS] +
                posterior_mean[i / COLS][i % COLS] + posterior_mean[(i + 1) / COLS][(i + 1) % COLS]) / 3;
        }

        prior_mean[0][0] = (posterior_mean[0][0] + (posterior_mean[1][0] + posterior_mean[2][0]) / 2) / 3;
        prior_mean[ROWS - 1][COLS - 1] = (posterior_mean[ROWS - 1][COLS - 1] +
            (posterior_mean[ROWS - 2][COLS - 1] + posterior_mean[ROWS - 3][COLS - 1]) / 2) / 3;

        prior_variance = posterior_variance;

        // APPLY BAYES' THEOREM
        for (size_t i = 0; i < x.size(); ++i) {
            for (size_t j = 0; j < x[i].size(); ++j) {
                if (prior_variance[i][j] > 0) {
                    posterior_variance[i][j] = (data_variance[i][j] * prior_variance[i][j]) /
                        (data_variance[i][j] + prior_variance[i][j]);
                }
                else {
                    posterior_variance[i][j] = 0;
                }
            }
        }

        for (size_t i = 0; i < x.size(); ++i) {
            for (size_t j = 0; j < x[i].size(); ++j) {
                if (prior_variance[i][j] > 0 && posterior_variance[i][j] > 0) {
                    posterior_mean[i][j] = ((prior_mean[i][j] / prior_variance[i][j]) +
                        (x[i][j] / data_variance[i][j])) * posterior_variance[i][j];
                }
                else {
                    posterior_mean[i][j] = prior_mean[i][j];
                }
            }
        }

        for (size_t i = 0; i < x.size(); ++i) {
            for (size_t j = 0; j < x[i].size(); ++j) {
                upper[i][j] = std::pow(prior_mean[i][j] - x[i][j], 2);
                lower[i][j] = 2 * (prior_variance[i][j] + data_variance[i][j]);
                first[i][j] = (-upper[i][j] / lower[i][j]);
                second[i][j] = std::sqrt(2 * M_PI) * (prior_variance[i][j] + data_variance[i][j]);
                evidence[i][j] = std::exp(first[i][j]) / second[i][j];
            }
        }

        evidence_derivative = std::mean(evidence) - evidence_previous;
        evidence_previous = std::mean(evidence);

        chi2_data = 0;
        for (size_t i = 0; i < x.size(); ++i) {
            for (size_t j = 0; j < x[i].size(); ++j) {
                chi2_data += std::pow((x[i][j] - posterior_mean[i][j]), 2) / data_variance[i][j];
            }
        }
        chi2_data /= N;

        double chi2_data_derivative = chi2_data - chi2_data_previous;
        chi2_data_previous = chi2_data;

        double chi2_data_snd_derivative = chi2_data_derivative - chi2_data_derivative_previous;
        chi2_data_derivative_previous = chi2_data_derivative;
	if(iterations == 1):
          chi2_data_min = chi2_data;
	    
	    
        if ((chi2_data > 1) && (evidence_derivative < 0) && (chi2_data_snd_derivative < tolerance) ||
            (iterations > max_iterations)) {
            break;
        }
        iterations++;

        for (size_t i = 0; i < x.size(); ++i) {
            for (size_t j = 0; j < x[i].size(); ++j) {
                model_weight[i][j] = evidence[i][j] * chi2_data;
            }
        }

        for (size_t i = 0; i < x.size(); ++i) {
            for (size_t j = 0; j < x[i].size(); ++j) {
                bayesian_weight[i][j] += model_weight[i][j];
                bayesian_model[i][j] += (model_weight[i][j] * posterior_mean[i][j]);
            }
        }
    }

    for (size_t i = 0; i < x.size(); ++i) {
        for (size_t j = 0; j < x[i].size(); ++j) {
            model_weight[i][j] = initial_evidence[i][j] * chi2_data_min;
        }
    }

    for (size_t i = 0; i < x.size(); ++i) {
        for (size_t j = 0; j < x[i].size(); ++j) {
            bayesian_weight[i][j] += model_weight[i][j];
            bayesian_model[i][j] += (model_weight[i][j] * x[i][j]);
        }
    }

    for (size_t i = 0; i < x.size(); ++i) {
        for (size_t j = 0; j < x[i].size(); ++j) {
            if (bayesian_weight[i][j] > 0) {
                x[i][j] = bayesian_model[i][j] / bayesian_weight[i][j];
            }
        }
    }

    return x;
}
//not guaranteed to be correct or useful.
//for best results, calculate sigma by taking the 2dfft of your stft, take the abs of that,
//find the atd of that, threshold the 2dfft by using where the abs<atd as your criteria, filling with zeros,
//invert the 2dfft, take the real(cause 2dfft always pushes complex?) and take the mean of the abs of that,
//and you have your sigma. Now, for a more precise, localized sigma value, multiply sigma by the locally normalized
//entropy value(per row) and you'll have a little bit better estimator(in time). 
//note that this method is really more suitable for AM and wider bandwidths, and has not been adapted by me yet

//in this domain, to get our 2d fft, just pad the array with zeros to 512, filling so that our data goes into the 0,0 corner of our 
//512, 512 array. use the abs of the logit. Now, first apply rfft to columns, and then rows. when you go to reverse, reverse the order.
//finally, crop it back to the original size.
	
void information_estimate_large(std::array<std::array<double, 192>, 257>& data, std::array<std::array<double, 192>, 257>& output, double kernelsize) {
    int odd = static_cast<int>(std::fmod(kernelsize, 2));
    //calculate our logit 
    //calculate the maximum
    std::array<std::array<double, kernelsize>, kernelsize> patch; // Subset of data array

    for (int x = kernelsize / 2; x < data.size() - (kernelsize / 2 + odd); ++x) {
        for (int y = kernelsize / 2; y < data[x].size() - (kernelsize / 2 + odd); ++y) {
            for (int i = 0; i < kernelsize; ++i) {
                for (int j = 0; j < kernelsize; ++j) {
                    patch[i][j] = data[x - kernelsize / 2 + i][y - kernelsize / 2 + j];
                }
            }
            std::array<double, 257> raveled; // Flattened patch array
            int index = 0;
            for (const auto& row : patch) {
                for (const auto& value : row) {
                    raveled[index++] = value; // and update our index
                }
            }
            
            // Partial sort the raveled array
            auto raveled_begin = raveled.begin();
            auto raveled_end = raveled.begin() + index;
            std::partial_sort(raveled_begin, raveled_end, raveled_end);
            
            // Interpolate the sorted array to a range of [0, 1]
            double range_min = raveled_begin[0];
            double range_max = raveled_end[-1];
            for (int i = 0; i < index; ++i) {
                raveled_begin[i] = (raveled_begin[i] - range_min) / (range_max - range_min);
            }
            
            double sigma = (1 - corrcoef(raveled, logit,index)) / maximum; //will need a modified corrceof for this one
            output[x][y] = sigma;
        }
    }
}

#now, the way we use this is - we start at 5, and take 15(that's 5-16 inclusive, up to 257 total ravel size) as our kernel size.
# we'll calculate this repeatedly and add it to an array of 192,257. then we divide by 15- get the mean.
#normalize this product. subtract it from 1, then take the abs.
#now multiply it by the mean of the absolute of the data.
#now anywhere less than our singular sigma, set to our singular sigma.
#now take the square root of this array. 
#now you have your noise variance computation, somewhat localized, and ready for use in fabada in each frame.


